/* SPDX-License-Identifier: GPL-2.0-or-later */

#pragma once

#define TAPPING_TERM 175

#define AUTO_SHIFT_TIMEOUT 150
#define NO_AUTO_SHIFT_ALPHA
